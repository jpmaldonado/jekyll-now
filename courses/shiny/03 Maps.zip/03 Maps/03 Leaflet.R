df <- read.csv("data/tomslee_airbnb_brno_1500_2017-07-20.csv")
head(df)

##############################
# LEAFLET PACKAGE
##############################

install.packages("leaflet")
install.packages("digest")

library(leaflet)
library(dplyr)


# Base map
df %>% 
  leaflet %>% 
  addTiles() %>% 
  addMarkers(~longitude, ~latitude)

##############################
# Popups and labels
##############################

# Popups appear when you click

df %>% 
  leaflet %>% 
  addTiles() %>% 
  addMarkers(~longitude, ~latitude, popup = ~as.character(overall_satisfaction))


# Labels appear when you hover
df %>% 
  leaflet %>% 
  addTiles() %>% 
  addMarkers(~longitude, ~latitude, label = ~as.character(overall_satisfaction))

# Price and overall satisfaction
custom_popup <- paste0("<strong> Price: </strong>", df$price, "<br>",
                       "<strong> Overall satisfaction: </strong>", df$overall_satisfaction)
df %>% 
  leaflet %>% 
  addTiles() %>% 
  addMarkers(~longitude, ~latitude, popup = custom_popup)


##############################
# Customized Markers
###############################
# Icon libraries: 
# http://glyphicons.com/
# https://fontawesome.com/cheatsheet

markerIcon <- awesomeIcons(
  icon = "home", 
  markerColor = "red"
)

df %>% 
  leaflet %>% 
  addTiles() %>% 
  addAwesomeMarkers(~longitude, ~latitude, icon =markerIcon)

##############################
# Conditional color
##############################

colorByPrice <- function(prices){
  ifelse(prices < 30,"blue", "red" )
}
  
  markerIcon <- awesomeIcons(
    icon = "home", 
    markerColor = colorByPrice(df$price)
  )

df %>% 
  leaflet %>% 
  addTiles() %>% 
  addAwesomeMarkers(~longitude, ~latitude, icon =markerIcon)  

##############################
# Circle markers by room type
##############################
df <- df %>% filter(price <70)
pal <- colorFactor(c("green","yellow","red"), domain = df$room_type)

df %>% 
  leaflet %>% 
  addTiles() %>% 
  addCircleMarkers(~longitude,
                   ~latitude, 
                   radius = ~price/5, 
                   color = ~pal(room_type), 
                   popup = paste(~room_type, ~price),
                   stroke = F, 
                   fillOpacity = 0.5)  
  

##############################
# Legends
##############################
df <- df %>% filter(price <70)
pal <- colorFactor(c("green","yellow","red"), domain = df$room_type)

df %>% 
  leaflet %>% 
  addTiles() %>% 
  addCircleMarkers(~longitude,
                   ~latitude, 
                   radius = ~price/5, 
                   color = ~pal(room_type), 
                   popup = paste(~room_type, ~price),
                   stroke = F, 
                   fillOpacity = 0.5) %>% 
  addLegend("bottomright", 
            pal = pal, 
            values = ~df$room_type,
            title = "Room type")


# Legend and color for a numeric marker
pal <- colorNumeric("YlOrRd", domain = df$price)

df %>% 
  leaflet %>% 
  addTiles() %>% 
  addCircleMarkers(~longitude,
                   ~latitude, 
                   radius = ~10, 
                   color = ~pal(price), 
                   stroke = F, 
                   fillOpacity=0.5) %>% 
  addLegend("topleft", 
            pal = pal, 
            values = ~df$price,
            title = "Price per night ", 
            labFormat = labelFormat(suffix=" EUR"))


##############################
# Shapefiles
##############################
install.packages("rgdal")

library(rgdal)

shapefile <- readOGR("../MC.shp")

# hack to read the shapefile in long/lat format for leaflet
shapeData <- spTransform(shapefile, CRS("+proj=longlat +datum=WGS84 +no_defs"))

leaflet()  %>% 
  addPolygons(data=shapeData)

districts <- unique(shapefile$NAZEV) #unique district names
fake_data <- data.frame(district = districts, 
                        value = round(1000+100*rnorm(length(districts),2)))


shapeData@data <- left_join(shapeData@data, fake_data, by = c("NAZEV"="district")) 

pal <- colorNumeric("YlOrRd", domain = shapeData$value)

custom_popup <- paste0("<strong>District: </strong>", shapeData@data$NAZEV,
                       "<br>",
                       "<strong>Indicator: </strong>", shapeData@data$value)
shapeData %>% 
  leaflet()  %>% 
  addTiles() %>%
  addPolygons(fillColor = ~pal(value),
                opacity = 1,
                stroke = T,
                weight = 1,
                color = "orange",
                popup = custom_popup)
