
dashboardPage(skin = "purple",
                    dashboardHeader(title="Brno Airbnb Analyzer"),
                    dashboardSidebar(
                      sidebarMenu(
                        menuItem("Location", 
                                 tabName = "roomType",
                                 icon =icon("map"))
                      )
                    ), 
                    dashboardBody(
                      tabItems(
                        tabItem(tabName = "roomType", 
                                fluidRow(
                                  column(width = 4,
                                         selectInput("rt", "Choose room type", 
                                                     choices = unique(as.character(brno$room_type)),
                                                     selected = unique(as.character(brno$room_type))[1])
                                         )
                                  ,column(width = 4, 
                                          sliderInput("reviews", 
                                                      "Number of reviews",
                                                      min = min(brno$reviews),
                                                      max = max(brno$reviews), 
                                                      value = mean(brno$reviews)))
                                  
                                  , column(width = 4, sliderInput("satisf",
                                                                  "Overall Satisfaction", 
                                                                  min = min(brno$overall_satisfaction),
                                                                  max = max(brno$overall_satisfaction), 
                                                                  value = mean(brno$overall_satisfaction)))
                                )
                                
                                , actionButton("recalc", "Redraw map")
                                , leafletOutput("brnoMap"))
                      )
                    )
)


