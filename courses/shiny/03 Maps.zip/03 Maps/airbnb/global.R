library(shiny)
library(shinydashboard)
library(ggplot2)
library(dplyr)
library(plotly)


brno <- read.csv("./data/tomslee_airbnb_brno_1500_2017-07-20.csv")
brno <- brno %>% filter(price < 70)
