function(input, output){

  ## A reactive object: filtering out the data from the chosen room type
  brnoFilteredRT <- eventReactive(input$recalc, {
    brno %>% 
      filter(room_type==input$rt) %>%
      filter(reviews>=as.numeric(input$reviews)) %>%
      filter(overall_satisfaction > as.numeric(input$satisf))
      
                    
    }, ignoreNULL = F)
  
  ## The part of the map that gets modified

  output$brnoMap <- renderLeaflet({
    custom_popup <- paste0("<strong> Room Type: </strong>", brnoFilteredRT()$room_type, "<br>",
                           "<strong> Price: </strong>", brnoFilteredRT()$price, "<br>",
                           "<strong> Overall satisfaction: </strong>", brnoFilteredRT()$overall_satisfaction, "<br>",
                           "<strong> Number of reviews: </strong>", brnoFilteredRT()$reviews, "<br>")
    
    pal <- colorNumeric("YlOrRd", domain = brno$price)
    
    leaflet() %>% 
      setView(lng = 16.60198, lat = 49.20054, zoom = 12) %>%
      addTiles() %>%
      addCircleMarkers(~longitude,
                       ~latitude, 
                       radius = ~10, 
                       color = ~pal(price), 
                       stroke = F, 
                       popup = custom_popup,
                       fillOpacity=0.5,
                       layerId = ~room_id,
                       data=brnoFilteredRT())
    
    
    
    
  })  
    

}
