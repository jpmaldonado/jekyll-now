library(shiny)
library(shinydashboard)
library(leaflet)

brno <- read.csv("../airbnb/data/tomslee_airbnb_brno_1500_2017-07-20.csv")