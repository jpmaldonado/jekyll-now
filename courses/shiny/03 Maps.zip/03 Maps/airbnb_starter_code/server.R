shinyServer(function(input, output) {

  
  filteredData <- eventReactive(input$redraw, {
    subset(brno, room_type == input$rt)
  })
  
  output$brnoMap <- renderLeaflet({
    leaflet() %>% 
      addTiles() %>%
      addMarkers(lng = ~longitude,
                 lat = ~latitude,
                 popup = ~room_type,
                 data = filteredData())
  })

})
