dashboardPage(
  dashboardHeader(),
  dashboardSidebar(
    
  ),
  dashboardBody(
      selectInput("rt", "Choose room type", choices = unique(brno$room_type) ),
      actionButton("redraw", "Redraw map"),
      leafletOutput("brnoMap")
                )
)
