# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 20:52:58 2018

@author: jpmaldonado
"""

import pandas as pd
import numpy as np

df = pd.read_csv("titanic.csv")
df['Embarked'] = df['Embarked'].astype(str)

df.info() 

# Observe we have a lot of missing values!


'''
1. Keep only the following columns: 
     'Survived','Pclass','Sex','Age','Parch','Embarked'
'''

# Answer:
df = df[['Survived','Pclass','Sex','Age','Parch','Embarked']]

'''
2. Replace `Sex` and `Embarked`  by numeric values using LabelEncoder. 
    You need *two* different label encoders
'''

# Answer:
from sklearn.preprocessing import LabelEncoder

le_sex = LabelEncoder()
le_port = LabelEncoder()

df['Sex'] = le_sex.fit_transform(df['Sex'])
df['Embarked'] = le_sex.fit_transform(df['Embarked'])


# We can look at some charts to get an intuition of the data
# If you don't have seaborn installed, try `!pip install seaborn` in the 
# iPython console

import seaborn as sns

sns.pairplot(df.dropna(axis=0), kind="scatter", hue="Survived")

# Correlogram
sns.heatmap(df.corr())


# So it seems like gender might play an important role... 

# Let's deal with the missing age values. 
# One possibility is to replace them with the average

mean_age = np.mean(df['Age'])

for ix in range(len(df)):
    if np.isnan(df.loc[ix,'Age']):
        df.loc[ix,'Age'] = mean_age
              
df.info() # check that everything is good now

'''
3. Modelling time! Create a logistic regression model. Do the coefficients 
resemble the heatmap above?
'''       

# Answer:
y = df['Survived']
X = df[['Pclass','Sex','Age','Parch','Embarked']]

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

X_train, X_test, y_train, y_test = train_test_split(X,y)

clf = LogisticRegression()
clf.fit(X_train,y_train)
clf.score(X_test, y_test)


# Do
features = X.columns.values
coefs = clf.coef_

print("Most important features")
for feature, coef in sorted(zip(features,coefs[0]), key=lambda x: x[1]):
    print("{} : {} ".format(feature, coef))

'''
4. YOUR TURN! Make a better model. You can
- Use some of the other columns
- Change the replacement method for the Age column (the median instead of the
mean, for example)
- Add preprocessing steps
- Use other methods (random forest, decision trees)
'''