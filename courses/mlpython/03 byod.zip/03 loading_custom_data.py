# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 19:35:59 2018

@author: jpmaldonado
"""

import pandas as pd

df = pd.read_csv("sonar.csv")

# Mmm wrong headers
len(df.columns)

# Read it again with the correct headers
cols = ['att_' + str(c+1) for c in range(60)]+['class']
df = pd.read_csv("sonar.csv", header = None, names = cols)

# scikit-learn needs numeric values (unlike, e.g. R)... 
from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()
df['class_numeric'] = le.fit_transform(df['class'])

# A different way
df['class_test'] = df['class'].map(lambda x: 1 if x=='R' else 0)                            

# Let's get rid of it
df.drop('class_test', axis=1, inplace=True)

# Show the classes
le.classes_

# Compute results back
le.inverse_transform([0,1,0])

########################
# Introducing pipelines
########################

# Recap: how would we apply logistic regression?
from sklearn.linear_model import LogisticRegression
lr = LogisticRegression()

X = df[[c for c in df.columns if c != 'class_numeric']]
y = df['class_numeric']


# train/test split
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X,y)

lr.fit(X_train,y_train)
lr.score(X_test,y_test)

'''
Easy enough... but not the full story... Sometimes we need to:
- be sure that the data      
'''     
from sklearn.preprocessing import StandardScaler
scl = StandardScaler()

X_train_rescaled = scl.fit_transform(X_train)
X_test_rescaled = scl.transform(X_test)

# fit the model again
lr.fit(X_train_rescaled,y_train)
lr.score(X_test_rescaled, y_test)

# so, better! Sometimes it's better to have a more 


from sklearn.pipeline import Pipeline

estimator = Pipeline(steps = [('z-score',scl), 
                              ('lr', lr)])
estimator.fit(X_train,y_train)    
estimator.score(X_test,y_test)


